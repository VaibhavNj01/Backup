package com.example.SpringCache;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCacheApplicationTests {

	@Test
	void contextLoads() {
	}

}
