package com.example.springmapstruct;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringmapstructApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringmapstructApplication.class, args);
	}

}
