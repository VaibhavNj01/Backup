package com.example.springmapstruct;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringmapstructApplicationTests {

	@Test
	void contextLoads() {
	}

}
